# Ansible role: ceph-iscsi

Documentation is available at http://docs.ceph.com/ceph-ansible/.
