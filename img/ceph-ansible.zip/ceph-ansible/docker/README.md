This directory includes Dockerfiles for building development environments to
run ceph-ansible.
